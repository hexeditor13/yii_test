$( document ).ready(function() {
	$('#modalButton').click(function(e){
		e.preventDefault();
		$('#modal').modal('show').find('#modalContent').load($(this).attr('value'));
	});

	$("body").on('click','#invoicesGrid a[title="Update"],#invoicesGrid a[title="View"]',function(e){
		e.preventDefault();
		$('#modal').modal('show').find('#modalContent').load($(this).attr('href'));
	});

	checkIfInvoicesSelected();

	$('.check_mass_delete').click(function(){
		if($(".massdelete").is(":hidden"))
		{
			$(".massdelete").show();
		}
		checkIfInvoicesSelected();
	});

	$('.massdelete').click(function(e){
		let toDelete = confirm('Вы действительно хотите удалить выбранные записи?');
		if (!toDelete)
		{
			e.preventDefault();
		}
	});

	 function checkIfInvoicesSelected()
	 {
		 if ($('.check_mass_delete:checked').length == 0)
		 {
		 	 $(".massdelete").hide();
		 }
	 }

});