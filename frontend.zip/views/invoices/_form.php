<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model frontend\models\Invoices */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="invoices-form">

    <?php $form = ActiveForm::begin(['id' => $model->formName(),'options' => ['data-pjax' => true ]]); ?>

    <?= $form->field($model, 'from_d')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'where_d')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'recipient')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'status')->dropDownList([
	    'Ожидает доставки' => 'Ожидает доставки',
	    'Доставлено' => 'Доставлено',
	    'В пути'=>'В пути',
	    'Принято на склад'=>'Принято на склад',
	    'Возвращен'=>'Возвращен'
	],['prompt' => 'Выберите статус...']); ?>

    <div class="form-group">
        <?= Html::submitButton('Сохранить', ['class' => 'btn btn-success']) ?>
    </div>

    <div id="messageFromAjax"></div>

    <?php ActiveForm::end(); ?>

</div>

<?php 

$script = <<< JS

﻿$('form#{$model->formName()}').on('beforeSubmit', function(e)
{
	var \$form = $(this);
	$.post(
		\$form.attr("action"), 
		\$form.serialize()
	)
	.done(function(result) {
	result = JSON.parse(result);
	if(result.status == 1)
	{
		if (result.action == 'create')
		{
			$(\$form).trigger("reset");
		}
		$("#messageFromAjax").html('Информация добавлена в базу!');
		setTimeout(function() {
		        $("#messageFromAjax").hide();
		    }, 3000);
		$.pjax.reload({container:'#invoicesGrid', timeout: false}); 
	}
	else if(result.status == 0)
	{
		$("#messageFromAjax").html('Ошибка! Информация не добавлена в базу');
	}
	}).fail(function()
	{
		console.log("server error");
	});
	return false;
});

JS;
$this->registerJs($script);

?>