<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
use yii\bootstrap\Modal;
use yii\helpers\Url;
/* @var $this yii\web\View */
/* @var $searchModel frontend\models\InvoicesSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Накладные';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="invoices-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::button('Добавить накладную', ['value' => Url::to('/invoices/create'), 'class' => 'btn btn-success', 'id' => 'modalButton']) ?>
    </p>

    <?php

    Modal::begin(
        [
            'header' => '<h4>Накладные</h4>',
            'id' => 'modal',
            'size' => 'modal-lg',
        ]
    );

    echo '<div id="modalContent"></div>';

    Modal::end();

    ?>

    <?=Html::beginForm(['invoices/massdelete'],'post');?>
    
    <?php Pjax::begin(['id'=>'invoicesGrid']); ?>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            [
              'class' => 'yii\grid\CheckboxColumn', 'checkboxOptions' => function($model) {
                    return ['class' => 'check_mass_delete'];
                },
            ],
            'id',
            'from_d',
            'where_d',
            'recipient',
            'status',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>

    <?php Pjax::end(); ?>

    <?=Html::submitButton('Удалить выбранные', ['class' => 'btn btn-info massdelete']);?>

    <?= Html::endForm();?> 

</div>
