<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "invoices".
 *
 * @property int $id
 * @property string $from_d
 * @property string $where_d
 * @property string $recipient
 * @property string $status
 */
class Invoices extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'invoices';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['from_d', 'where_d', 'recipient', 'status'], 'required'],
            [['from_d', 'where_d', 'recipient', 'status'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'from_d' => 'Откуда',
            'where_d' => 'Куда',
            'recipient' => 'Получатель',
            'status' => 'Статус',
        ];
    }

    /**
     * {@inheritdoc}
     * @return InvoicesQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new InvoicesQuery(get_called_class());
    }
}
